package janine.tavares.ourcosmicneighbors.TelasQuiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import janine.tavares.ourcosmicneighbors.R
import janine.tavares.ourcosmicneighbors.model.Quiz
import kotlinx.android.synthetic.main.activity_tela_quiz4.*

class TelaQuiz4 : AppCompatActivity(), View.OnClickListener{

    lateinit var button4Mercury: Button
    lateinit var button4Saturn: Button
    lateinit var button4Pluto: Button
    lateinit var button4Jupiter: Button
    lateinit var textView4Question: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_quiz4)

        initializer()
        val quiz = Quiz(getString(R.string.question4), getString(R.string.correctAnswer4), getString(R.string.notCorrectAnswer4))

        textView4Question.text = quiz.question

        button4Jupiter.setOnClickListener(this@TelaQuiz4)
        button4Saturn.setOnClickListener(this@TelaQuiz4)
        button4Pluto.setOnClickListener(this@TelaQuiz4)
        button4Mercury.setOnClickListener(this@TelaQuiz4)
    }



    override fun onClick(p0: View?) {



        if (p0?.id != R.id.button4Saturn ) {
            Toast.makeText(this@TelaQuiz4, R.string.notCorrectAnswer4, Toast.LENGTH_SHORT).show()
            button4Mercury.setBackgroundColor(getColor(R.color.wrong))
            button4Saturn.setBackgroundColor(getColor(R.color.right))
            button4Pluto.setBackgroundColor(getColor(R.color.wrong))
            button4Jupiter.setBackgroundColor(getColor(R.color.wrong))
            Handler().postDelayed({
                val intent = Intent(this, TelaQuiz5::class.java)
                startActivity(intent)
            }, 2000)


        }
        else {
            Toast.makeText(this@TelaQuiz4, R.string.correctAnswer4, Toast.LENGTH_SHORT).show()
            button4Saturn.setBackgroundColor(getColor(R.color.right))
            Handler().postDelayed({
                val intent = Intent(this, TelaQuiz5::class.java)
                startActivity(intent)
            }, 2000)

        }
    }

    fun initializer() {
        button4Jupiter = findViewById(R.id.button4Jupiter)
        button4Saturn = findViewById(R.id.button4Saturn)
        button4Pluto = findViewById(R.id.button4Pluto)
        button4Mercury = findViewById(R.id.button4Mercury)
        textView4Question = findViewById(R.id.textView4Question)
    }
    }
