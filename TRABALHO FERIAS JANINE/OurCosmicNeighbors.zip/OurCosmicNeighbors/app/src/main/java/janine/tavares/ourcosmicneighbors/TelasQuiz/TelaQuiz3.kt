package janine.tavares.ourcosmicneighbors.TelasQuiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import janine.tavares.ourcosmicneighbors.Mercury
import janine.tavares.ourcosmicneighbors.R
import janine.tavares.ourcosmicneighbors.model.Quiz
import kotlinx.android.synthetic.main.activity_tela_quiz2.*

class TelaQuiz3 : AppCompatActivity(), View.OnClickListener {

    private lateinit var button3Mercury: Button
    private lateinit var button3Neptune: Button
    private lateinit var button3Pluto: Button
    private lateinit var button3Jupiter: Button
    private lateinit var textView3Question: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_quiz3)
        initializer()
        val quiz = Quiz(getString(R.string.question3), getString(R.string.correctAnswer3), getString(
                    R.string.notCorrectAnswer3))

        textView3Question.text = quiz.question

        button3Jupiter.setOnClickListener(this@TelaQuiz3)
        button3Neptune.setOnClickListener(this@TelaQuiz3)
        button3Pluto.setOnClickListener(this@TelaQuiz3)
        button3Mercury.setOnClickListener(this@TelaQuiz3)
    }

    fun initializer() {
        button3Jupiter = findViewById(R.id.button3Jupiter)
        button3Neptune = findViewById(R.id.button3Neptune)
        button3Pluto = findViewById(R.id.button3Pluto)
        button3Mercury = findViewById(R.id.button3Mercury)
        textView3Question = findViewById(R.id.textView3Question)
    }

    override fun onClick(p0: View?) {



        if (p0?.id != R.id.button3Pluto ) {
            Toast.makeText(this@TelaQuiz3, R.string.notCorrectAnswer3, Toast.LENGTH_SHORT).show()
            button3Mercury.setBackgroundColor(getColor(R.color.wrong))
            button3Neptune.setBackgroundColor(getColor(R.color.wrong))
            button3Pluto.setBackgroundColor(getColor(R.color.right))
            button3Jupiter.setBackgroundColor(getColor(R.color.wrong))
            Handler().postDelayed({
                val intent = Intent(this, TelaQuiz4::class.java)
                startActivity(intent)
            }, 2000)


        }
        else {
            Toast.makeText(this@TelaQuiz3, R.string.correctAnswer3, Toast.LENGTH_SHORT).show()
            button3Pluto.setBackgroundColor(getColor(R.color.right))
            Handler().postDelayed({
                val intent = Intent(this, TelaQuiz4::class.java)
                startActivity(intent)
            }, 2000)

        }
    }
}