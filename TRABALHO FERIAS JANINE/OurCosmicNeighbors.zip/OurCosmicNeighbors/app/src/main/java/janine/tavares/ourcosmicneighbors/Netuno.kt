package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Netuno : AppCompatActivity() {
    lateinit var audionetuno: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_netuno)


        audionetuno = findViewById(R.id.audionetuno)
        audionetuno.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Netuno, R.raw.neptune)
            mediaPlayer.start()
        }
//            playAudio(R.raw.neptune)
        }


    }
//
//    fun stop() {
//        if (mediaPlayer.isPlaying) {
//            mediaPlayer.stop()
//        }
//
//    }
//    override fun onStop() {
//        stop()
//        super.onStop()
//
//    }
//    fun initializer() {
//        audionetuno = findViewById(R.id.audionetuno)
//    }
//
//
//
//    fun playAudio(audio: Int) {
//        mediaPlayer = MediaPlayer.create(this@Netuno, audio)
//        mediaPlayer.start()
//    }
