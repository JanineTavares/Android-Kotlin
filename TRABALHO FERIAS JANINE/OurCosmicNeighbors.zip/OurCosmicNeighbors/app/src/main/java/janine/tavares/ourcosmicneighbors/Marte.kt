package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_marte.*

class Marte : AppCompatActivity() {

    lateinit var audiomarte: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_marte)


        audiomarte = findViewById(R.id.audiomarte)
        audiomarte.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Marte, R.raw.mars)
            mediaPlayer.start()
        }

//            playAudio(R.raw.mars)
//        }


    }

//             fun stop() {
//                if (mediaPlayer.isPlaying) {
//                mediaPlayer.stop()
//                 }
//
//        }
//            override fun onStop() {
//                 stop()
//                super.onStop()
//
//    }

//    fun initializer() {
//        audiomarte = findViewById(R.id.audiomarte)
//    }

//
//
//            fun playAudio(audio: Int) {
//                 mediaPlayer = MediaPlayer.create(this@Marte, audio)
//                    mediaPlayer.start()
//    }
}