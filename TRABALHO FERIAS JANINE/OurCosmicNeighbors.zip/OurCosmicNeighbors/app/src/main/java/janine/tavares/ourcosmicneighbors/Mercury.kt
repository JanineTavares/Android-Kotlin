package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Mercury : AppCompatActivity() {
    lateinit var audiomercurio: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mercury)


        audiomercurio = findViewById(R.id.audiomercurio)

        audiomercurio.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Mercury, R.raw.mercury)
            mediaPlayer.start()
//            playAudio(R.raw.mercury)
//        }


        }

//    fun stop() {
//        if (mediaPlayer.isPlaying) {
//            mediaPlayer.stop()
//        }
//
//    }
//    override fun onStop() {
//        stop()
//        super.onStop()
//
//    }

//        fun initializer() {
//            audiomercurio = findViewById(R.id.audiomercurio)
//        }
//
//    fun playAudio(audio: Int) {
//        mediaPlayer = MediaPlayer.create(this@Mercury, audio)
//        mediaPlayer.start()
//    }
    }
}



