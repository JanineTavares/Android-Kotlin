package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import kotlinx.android.synthetic.main.activity_plutao.*

class Plutao : AppCompatActivity() {
    lateinit var audioplutao: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_plutao)


        audioplutao = findViewById(R.id.audioplutao)

        audioplutao.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Plutao, R.raw.pluto)
            mediaPlayer.start()
        }

//            playAudio(R.raw.pluto)
//        }


    }
}

//    fun stop() {
//        if (mediaPlayer.isPlaying) {
//            mediaPlayer.stop()
//        }
//
//    }
//    override fun onStop() {
//        stop()
//        super.onStop()
//
//    }
//
//    fun initializer() {
//        audioplutao = findViewById(R.id.audioplutao)
//    }
//
//    fun playAudio(audio: Int) {
//        mediaPlayer = MediaPlayer.create(this@Plutao, audio)
//        mediaPlayer.start()
//    }
//}