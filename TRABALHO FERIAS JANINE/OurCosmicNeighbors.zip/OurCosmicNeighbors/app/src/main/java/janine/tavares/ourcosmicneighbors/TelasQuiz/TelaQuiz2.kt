package janine.tavares.ourcosmicneighbors.TelasQuiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import janine.tavares.ourcosmicneighbors.R
import janine.tavares.ourcosmicneighbors.model.Quiz
import kotlinx.android.synthetic.main.activity_tela_quiz2.*
import org.w3c.dom.Text

class TelaQuiz2 : AppCompatActivity(), View.OnClickListener {

    private lateinit var button2Mercury: Button
    private lateinit var button2Neptune: Button
    private lateinit var button2Pluto: Button
    private lateinit var button2Jupiter: Button
    private lateinit var textView2Question: TextView



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_quiz2)
        initializer()

        val quiz = Quiz(getString(R.string.question2), getString(R.string.correctAnswer2), getString(
                    R.string.notCorrectAnswer2))

        textView2Question.text = quiz.question

        button2Jupiter.setOnClickListener(this@TelaQuiz2)
        button2Neptune.setOnClickListener(this@TelaQuiz2)
        button2Pluto.setOnClickListener(this@TelaQuiz2)
        button2Mercury.setOnClickListener(this@TelaQuiz2)

    }
    fun initializer() {
        button2Jupiter = findViewById(R.id.button2Jupiter)
        button2Neptune = findViewById(R.id.button2Neptune)
        button2Pluto = findViewById(R.id.button2Pluto)
        button2Mercury = findViewById(R.id.button2Mercury)
        textView2Question = findViewById(R.id.textView2Question)
    }

    override fun onClick(p0: View?) {

        if (p0?.id != R.id.button2Mercury ) {
            Toast.makeText(this@TelaQuiz2, R.string.notCorrectAnswer2, Toast.LENGTH_SHORT).show()
            button2Mercury.setBackgroundColor(getColor(R.color.right))
            button2Neptune.setBackgroundColor(getColor(R.color.wrong))
            button2Pluto.setBackgroundColor(getColor(R.color.wrong))
            button2Jupiter.setBackgroundColor(getColor(R.color.wrong))
            Handler().postDelayed({
                val intent = Intent(this, TelaQuiz3::class.java)
                startActivity(intent)
            }, 2000)

        }
        else {
            Toast.makeText(this@TelaQuiz2, R.string.correctAnswer2, Toast.LENGTH_SHORT).show()
            button2Mercury.setBackgroundColor(getColor(R.color.right))
            Handler().postDelayed({
                val intent = Intent(this, TelaQuiz3::class.java)
                startActivity(intent)
            }, 2000)

        }
    }
}