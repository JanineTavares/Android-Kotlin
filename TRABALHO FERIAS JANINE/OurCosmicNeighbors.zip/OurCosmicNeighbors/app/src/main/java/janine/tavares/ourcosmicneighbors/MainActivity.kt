package janine.tavares.ourcosmicneighbors

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.View
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.reflect.Type
import java.util.*
import kotlin.reflect.KType
import janine.tavares.ourcosmicneighbors.Plutao as Plutao1
import java.lang.Class as Class1

class MainActivity : AppCompatActivity() {


    private lateinit var mercury: Button
    private lateinit var venus: Button
    private lateinit var mars: Button
    private lateinit var jupiter: Button
    private lateinit var saturn: Button
    private lateinit var uranus: Button
    private lateinit var neptune: Button
    private lateinit var pluto: Button
    private lateinit var buttonquiz: Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializer()

        mercury.setOnClickListener {
            var intent = Intent(this@MainActivity, Mercury::class.java)
            startActivity(intent)
            vibrate()

        }

        venus.setOnClickListener {
            var intent = Intent(this@MainActivity, Venus::class.java)
            startActivity(intent)
            vibrate()

        }

        mars.setOnClickListener {
           var intent = Intent(this@MainActivity, Marte::class.java)
            startActivity(intent)
            vibrate()

        }

        jupiter.setOnClickListener {
            var intent = Intent(this@MainActivity, Jupiter::class.java)
            startActivity(intent)
            vibrate()

        }

        saturn.setOnClickListener {
            var intent = Intent(this@MainActivity, Saturno::class.java)
            startActivity(intent)
            vibrate()

        }

        uranus.setOnClickListener {
            var intent = Intent(this@MainActivity, Urano::class.java)
            startActivity(intent)
            vibrate()
        }

        neptune.setOnClickListener {
            var intent = Intent(this@MainActivity, Netuno::class.java)
            startActivity(intent)
            vibrate()
        }

        pluto.setOnClickListener {
            var intent = Intent(this@MainActivity, Plutao1::class.java)
            startActivity(intent)
            vibrate()
        }

        buttonquiz.setOnClickListener {
            var intent = Intent(this@MainActivity, Quiz::class.java)
            startActivity(intent)
            vibrate()
        }


    }




    fun vibrate() {
        val pattern = longArrayOf(0, 100, 0)
        val hardware = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator

        hardware?.let {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    hardware.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else
                    hardware.vibrate(pattern, -1)
            }
    }

    fun initializer() {
        mercury = findViewById(R.id.mercury)
        venus = findViewById(R.id.venus)
        mars = findViewById(R.id.mars)
        jupiter = findViewById(R.id.jupiter)
        saturn = findViewById(R.id.saturn)
        uranus = findViewById(R.id.uranus)
        neptune = findViewById(R.id.neptune)
        pluto = findViewById(R.id.pluto)
        buttonquiz = findViewById(R.id.buttonquiz)
    }

//    fun abrirTela(context: Context) {
//        var intent = Intent(this@MainActivity, context::class.java)
//        startActivity(intent)
//        vibrate()
//    }
    }





