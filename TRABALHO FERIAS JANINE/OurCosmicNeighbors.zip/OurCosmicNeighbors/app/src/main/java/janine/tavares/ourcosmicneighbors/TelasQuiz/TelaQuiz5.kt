package janine.tavares.ourcosmicneighbors.TelasQuiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import janine.tavares.ourcosmicneighbors.MainActivity
import janine.tavares.ourcosmicneighbors.R
import janine.tavares.ourcosmicneighbors.model.Quiz

class TelaQuiz5 : AppCompatActivity(), View.OnClickListener {

    lateinit var button5Mercury: Button
    lateinit var button5Saturn: Button
    lateinit var button5Mars: Button
    lateinit var button5Jupiter: Button
    lateinit var textView5Question: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_quiz5)

        initializer()
        val quiz = Quiz(getString(R.string.question5), getString(R.string.correctAnswer5), getString(R.string.notCorrectAnswer5))

        textView5Question.text = quiz.question

        button5Jupiter.setOnClickListener(this@TelaQuiz5)
        button5Saturn.setOnClickListener(this@TelaQuiz5)
        button5Mars.setOnClickListener(this@TelaQuiz5)
        button5Mercury.setOnClickListener(this@TelaQuiz5)
    }


    override fun onClick(p0: View?) {


        if (p0?.id != R.id.button5Mars) {
            Toast.makeText(this@TelaQuiz5, R.string.notCorrectAnswer5, Toast.LENGTH_SHORT).show()
            button5Mercury.setBackgroundColor(getColor(R.color.wrong))
            button5Saturn.setBackgroundColor(getColor(R.color.wrong))
            button5Mars.setBackgroundColor(getColor(R.color.right))
            button5Jupiter.setBackgroundColor(getColor(R.color.wrong))
            Handler().postDelayed({
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }, 2000)


        } else {
            Toast.makeText(this@TelaQuiz5, R.string.correctAnswer5, Toast.LENGTH_SHORT).show()
            button5Mars.setBackgroundColor(getColor(R.color.right))
            Handler().postDelayed({
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
            }, 2000)

        }
    }

    fun initializer() {
        button5Jupiter = findViewById(R.id.button5Jupiter)
        button5Saturn = findViewById(R.id.button5Saturn)
        button5Mars = findViewById(R.id.button5Mars)
        button5Mercury = findViewById(R.id.button5Mercury)
        textView5Question = findViewById(R.id.textView5Question)

    }
}