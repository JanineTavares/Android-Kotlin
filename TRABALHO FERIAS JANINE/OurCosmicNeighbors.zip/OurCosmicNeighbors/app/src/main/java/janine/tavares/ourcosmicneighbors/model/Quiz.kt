package janine.tavares.ourcosmicneighbors.model

import android.view.View

data class Quiz(var question: String, var correct: String, var notCorrect: String)




