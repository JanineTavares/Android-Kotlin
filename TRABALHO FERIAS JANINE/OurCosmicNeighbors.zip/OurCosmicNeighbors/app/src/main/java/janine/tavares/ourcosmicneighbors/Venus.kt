package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Venus : AppCompatActivity() {
    lateinit var audiovenus: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_venus)


        audiovenus = findViewById(R.id.audiovenus)
        audiovenus.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Venus, R.raw.venus)
            mediaPlayer.start()

        }
//            playAudio(R.raw.venus)
//        }


    }
}

//    fun stop() {
//        if (mediaPlayer.isPlaying) {
//            mediaPlayer.stop()
//        }
//
//    }
//    override fun onStop() {
//        stop()
//        super.onStop()
//
//    }
//
//    fun initializer() {
//        audiovenus = findViewById(R.id.audiovenus)
//    }
//
//    fun playAudio(audio: Int) {
//        mediaPlayer = MediaPlayer.create(this@Venus, audio)
//        mediaPlayer.start()
//    }
//}
