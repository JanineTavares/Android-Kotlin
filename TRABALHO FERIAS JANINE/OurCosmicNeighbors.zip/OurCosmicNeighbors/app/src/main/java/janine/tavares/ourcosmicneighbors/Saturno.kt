package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Saturno : AppCompatActivity() {
    lateinit var audiosaturno: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_saturno)

        audiosaturno = findViewById(R.id.audiosaturno)
        audiosaturno.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Saturno, R.raw.saturno)
            mediaPlayer.start()
        }
//        playAudio(R.raw.saturno)
//    }


    }
}
//
//fun stop() {
//    if (mediaPlayer.isPlaying) {
//        mediaPlayer.stop()
//    }
//
//}
//override fun onStop() {
//    stop()
//    super.onStop()
//
//}
//
//    fun initializer() {
//        audiosaturno = findViewById(R.id.audiosaturno)
//    }
//
//fun playAudio(audio: Int) {
//    mediaPlayer = MediaPlayer.create(this@Saturno, audio)
//    mediaPlayer.start()
//}
//}