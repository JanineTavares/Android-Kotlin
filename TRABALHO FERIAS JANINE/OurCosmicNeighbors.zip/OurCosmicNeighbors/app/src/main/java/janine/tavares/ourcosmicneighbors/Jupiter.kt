package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button


class Jupiter : AppCompatActivity(){

    lateinit var mediaPlayer: MediaPlayer
    lateinit var audiojupiter: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_jupiter)

        audiojupiter = findViewById(R.id.audiojupiter)

        audiojupiter.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Jupiter, R.raw.jupiter)
            mediaPlayer.start()

//            playAudio(R.raw.jupiter)
//        }


        }

//    fun stop() {
//        if (mediaPlayer.isPlaying) {
//            mediaPlayer.stop()
//        }
//
//    }
//
//    override fun onStop() {
//        stop()
//        super.onStop()
//
//    }

//        fun initializer() {
//
//        }
////        fun playAudio(audio: Int) {
////            mediaPlayer = MediaPlayer.create(this@Jupiter, audio)
////            mediaPlayer.start()
////        }
    }
}




