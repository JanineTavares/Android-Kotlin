package janine.tavares.ourcosmicneighbors.TelasQuiz

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import janine.tavares.ourcosmicneighbors.Jupiter
import janine.tavares.ourcosmicneighbors.R
import janine.tavares.ourcosmicneighbors.model.Quiz
import java.lang.reflect.Array
import kotlin.properties.Delegates

class TelaQuiz1 : AppCompatActivity(), View.OnClickListener{

    private lateinit var button1Uranus: Button
    private lateinit var button1Neptune: Button
    private lateinit var button1Pluto: Button
    private lateinit var button1Jupiter: Button
    private lateinit var textView1Question: TextView




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tela_quiz1)
        initializer()



        val quiz = Quiz(getString(R.string.question1), getString(R.string.correctAnswer1), getString(
                    R.string.notCorrectAnswer1))

        textView1Question.text = quiz.question

        button1Jupiter.setOnClickListener(this@TelaQuiz1)
        button1Neptune.setOnClickListener(this@TelaQuiz1)
        button1Pluto.setOnClickListener(this@TelaQuiz1)
        button1Uranus.setOnClickListener(this@TelaQuiz1)




}

fun initializer() {
    button1Jupiter = findViewById(R.id.button1Jupiter)
    button1Neptune = findViewById(R.id.button1Neptune)
    button1Pluto = findViewById(R.id.button1Pluto)
    button1Uranus = findViewById(R.id.button1Uranus)
    textView1Question = findViewById(R.id.textView1Question)
}

override fun onClick(p0: View?) {



    if (p0?.id != R.id.button1Jupiter ) {
        Toast.makeText(this@TelaQuiz1, R.string.notCorrectAnswer1, Toast.LENGTH_SHORT).show()
        button1Uranus.setBackgroundColor(getColor(R.color.wrong))
        button1Neptune.setBackgroundColor(getColor(R.color.wrong))
        button1Pluto.setBackgroundColor(getColor(R.color.wrong))
        button1Jupiter.setBackgroundColor(getColor(R.color.right))
        Handler().postDelayed({
            val intent = Intent(this, TelaQuiz2::class.java)
            startActivity(intent)
        }, 2000)


    }
    else {
        Toast.makeText(this@TelaQuiz1, R.string.correctAnswer1, Toast.LENGTH_SHORT).show()
        button1Jupiter.setBackgroundColor(getColor(R.color.right))
        Handler().postDelayed({
            val intent = Intent(this, TelaQuiz2::class.java)
            startActivity(intent)

        }, 2000)


    }
}
    }






