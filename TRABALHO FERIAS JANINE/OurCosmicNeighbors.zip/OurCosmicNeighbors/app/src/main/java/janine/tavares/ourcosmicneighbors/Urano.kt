package janine.tavares.ourcosmicneighbors

import android.media.MediaPlayer
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class Urano : AppCompatActivity() {
    lateinit var audiourano: Button
    lateinit var mediaPlayer: MediaPlayer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_urano)

        audiourano = findViewById(R.id.audiourano)



        audiourano.setOnClickListener {
            mediaPlayer = MediaPlayer.create(this@Urano, R.raw.urano)
            mediaPlayer.start()
        }
//            playAudio(R.raw.urano)
//        }


    }

//    fun stop() {
//        if (mediaPlayer.isPlaying) {
//            mediaPlayer.stop()
//        }
//
//    }
//    override fun onStop() {
//        stop()
//        super.onStop()
//
//    }

//    fun initializer() {
//        audiourano = findViewById(R.id.audiourano)
//
//    }

//    fun playAudio(audio: Int) {
//        mediaPlayer = MediaPlayer.create(this@Urano, audio)
//        mediaPlayer.start()
//    }
}